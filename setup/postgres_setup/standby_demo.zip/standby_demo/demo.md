PostgreSQL Replication with Docker
https://medium.com/swlh/postgresql-replication-with-docker-c6a904becf77


postgresql 14 配置主从复制(实时备份，流复制)基于docker
https://www.diaoyc.cn/archives/postgresql-14-pei-zhi-zhu-cong-fu-zhi-shi-shi-bei-fen-liu-fu-zhi-ji-yu-docker

